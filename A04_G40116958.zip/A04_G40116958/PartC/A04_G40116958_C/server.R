#
# This is the server logic of a Shiny web application. You can run the 
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)

# Read input file
#kickers <- read.csv("kickers.csv")

shinyServer(function(input, output) {
  
  output$Summary <- renderPrint({
    
    #get data
    temp <- input$file1
    temp2<-temp$datapath
    kickers<-read.csv(temp2)
    
    # Create the formula as a string
    myFormula <- paste("Success", " ~ ", input$inputvariable, sep = "")
    mymodel <- glm(formula=myFormula,
                   data=kickers,
                   family=binomial)
    summary(mymodel)
  })
  # This is to create a plot
  output$myPlot <- renderPlot({
    
    #get data
    temp3 <- input$file1
    temp4<-temp3$datapath
    kickers2<-read.csv(temp4)
    
    library(ggplot2)
    g <- ggplot(kickers2, aes_string(x=input$inputvariable, y=kickers2$Success))
    g <- g + geom_point()
    g <- g + stat_smooth(method="glm",
                         method.args=list(family="binomial"),
                         se=FALSE)
    print(g)
  })
})