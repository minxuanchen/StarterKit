#
# This is the server logic of a Shiny web application. You can run the 
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)

# Read input file
kickers <- read.csv("kickers.csv")
attach(kickers)
shinyServer(function(input, output) {
  output$Summary <- renderPrint({
    # Create the formula as a string
    myFormula <- paste("Success", " ~ ", input$inputvariable, sep = "")
    mymodel <- glm(formula=myFormula,
                   data=kickers,
                   family=binomial)
    summary(mymodel)
  })
  # This is to create a plot
  output$myPlot <- renderPlot({
    library(ggplot2)
    g <- ggplot(kickers, aes_string(x=input$inputvariable, y=Success))
    g <- g + geom_point()
    g <- g + stat_smooth(method="glm",
                         method.args=list(family="binomial"),
                         se=FALSE)
    print(g)
  })
})