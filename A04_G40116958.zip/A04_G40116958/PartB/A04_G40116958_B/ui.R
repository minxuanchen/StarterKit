#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
# 
#    http://shiny.rstudio.com/
#

library(shiny)

shinyUI(
  fluidPage(
    
    titlePanel("Part 2"),  #title of the app 
    
    sidebarLayout(
      
      #Set a side bar to input independent variable
      sidebarPanel( 
        selectInput("inputvariable", "Independent Variable:",
                    choices=c("Distance","ScoreDiff")),
        hr(),
        helpText("Set Independent Variable") #put some comments to help choose the variables
      ),
      
      #output summary and plots in the tabsetpanel
      tabsetPanel(type = "tabs",
                  tabPanel("Summary",
                           verbatimTextOutput("Summary")),
                  tabPanel("Plot", plotOutput("myPlot"))
      )
      
    )
  )
)